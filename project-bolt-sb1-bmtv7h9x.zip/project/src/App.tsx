import React from 'react';
import { BookOpen, CheckCircle, ArrowRight, Heart, Brain, Smile, Clock, Coffee, Users } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-teal-900 to-gray-900 text-white">
      {/* Hero Section */}
      <nav className="container mx-auto px-6 py-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Heart className="w-8 h-8 text-teal-400" />
          <span className="text-xl font-bold">Respire</span>
        </div>
        <button className="bg-teal-500 hover:bg-teal-600 px-6 py-2 rounded-full font-medium transition-all">
          Comprar Agora
        </button>
      </nav>

      <main className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center py-20">
          <div>
            <h1 className="text-5xl font-bold mb-6 leading-tight">
              Respire, <span className="text-teal-400">vai ficar</span> tudo bem
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Um guia completo para entender, gerenciar e superar a ansiedade com técnicas práticas e comprovadas.
            </p>
            <div className="flex gap-4 mb-12">
              <button className="bg-teal-500 hover:bg-teal-600 px-8 py-3 rounded-full font-medium flex items-center gap-2 transition-all">
                Começar Agora <ArrowRight className="w-5 h-5" />
              </button>
              <button className="border border-teal-500 hover:bg-teal-500/10 px-8 py-3 rounded-full font-medium transition-all">
                Saiba mais
              </button>
            </div>
            <div className="flex gap-8">
              <div>
                <h3 className="text-3xl font-bold text-teal-400">2000+</h3>
                <p className="text-gray-400">Leitores</p>
              </div>
              <div>
                <h3 className="text-3xl font-bold text-teal-400">200+</h3>
                <p className="text-gray-400">Avaliações</p>
              </div>
              <div>
                <h3 className="text-3xl font-bold text-teal-400">4.9</h3>
                <p className="text-gray-400">Estrelas</p>
              </div>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://i.imgur.com/QqHqCGY.jpg"
              alt="Capa do livro Ansiedade"
              className="rounded-2xl shadow-2xl shadow-teal-500/20 w-full"
            />
            <div className="absolute -bottom-10 -left-10 bg-gray-800/90 backdrop-blur-sm p-6 rounded-xl border border-teal-500/20">
              <div className="flex gap-4 items-center mb-4">
                <Brain className="w-8 h-8 text-teal-400" />
                <div>
                  <h4 className="font-medium">Transformação Mental</h4>
                  <p className="text-sm text-gray-400">Técnicas comprovadas</p>
                </div>
              </div>
              <div className="flex gap-4 items-center">
                <Smile className="w-8 h-8 text-teal-400" />
                <div>
                  <h4 className="font-medium">Bem-estar Garantido</h4>
                  <p className="text-sm text-gray-400">Resultados reais</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* About Section */}
        <section className="py-20 border-t border-teal-500/20">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="order-2 lg:order-1">
              <h2 className="text-3xl font-bold mb-6">Sobre o Livro</h2>
              <p className="text-gray-300 mb-6">
                "Ansiedade: Sintomas, Cuidados e Caminhos para a Paz Interior" é um guia completo que oferece uma abordagem prática e cientificamente fundamentada para lidar com a ansiedade no dia a dia.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-teal-400" />
                  <span>8 capítulos detalhados</span>
                </div>
                <div className="flex items-center gap-3">
                  <Coffee className="w-5 h-5 text-teal-400" />
                  <span>Exercícios práticos em cada seção</span>
                </div>
                <div className="flex items-center gap-3">
                  <Users className="w-5 h-5 text-teal-400" />
                  <span>Comunidade de suporte online</span>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <img
                src="https://i.imgur.com/QqHqCGY.jpg"
                alt="Capa do livro Ansiedade"
                className="w-48 mx-auto rounded-lg shadow-lg"
              />
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 border-t border-teal-500/20">
          <h2 className="text-3xl font-bold text-center mb-16">O que você vai encontrar neste ebook</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <BookOpen className="w-6 h-6 text-teal-400" />,
                title: "Conteúdo Completo",
                description: "200 páginas de conteúdo prático e transformador, incluindo exercícios de respiração e meditação guiada"
              },
              {
                icon: <CheckCircle className="w-6 h-6 text-teal-400" />,
                title: "Exercícios Práticos",
                description: "Mais de 30 exercícios práticos para aplicar no seu dia a dia, com instruções passo a passo"
              },
              {
                icon: <Heart className="w-6 h-6 text-teal-400" />,
                title: "Suporte Contínuo",
                description: "Acesso vitalício ao grupo exclusivo de apoio com outros leitores e especialistas"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-gray-800/50 backdrop-blur-sm p-8 rounded-xl border border-teal-500/20 hover:border-teal-500/50 transition-all">
                <div className="bg-gray-700/50 w-12 h-12 flex items-center justify-center rounded-lg mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-medium mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Content Overview */}
        <section className="py-20 border-t border-teal-500/20">
          <h2 className="text-3xl font-bold text-center mb-16">Conteúdo do Ebook</h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              "Entendendo a Ansiedade: Uma Visão Científica",
              "Identificando Gatilhos e Padrões",
              "Técnicas de Respiração e Relaxamento",
              "Mindfulness e Meditação Guiada",
              "Reestruturação de Pensamentos",
              "Construindo Hábitos Saudáveis",
              "Estratégias para Crises de Ansiedade",
              "Plano de Ação Personalizado"
            ].map((chapter, index) => (
              <div key={index} className="flex items-center gap-4 p-4 bg-gray-800/30 rounded-lg">
                <span className="text-teal-400 font-bold">{(index + 1).toString().padStart(2, '0')}</span>
                <span>{chapter}</span>
              </div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center py-20 border-t border-teal-500/20">
          <h2 className="text-3xl font-bold mb-6">Comece sua jornada hoje</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Não deixe a ansiedade controlar sua vida. Aprenda técnicas comprovadas e retome o controle do seu bem-estar com nosso guia completo.
          </p>
          <div className="flex flex-col items-center gap-4">
            <button className="bg-teal-500 hover:bg-teal-600 px-8 py-3 rounded-full font-medium flex items-center gap-2 transition-all">
              Garantir meu ebook por R$97 <ArrowRight className="w-5 h-5" />
            </button>
            <span className="text-sm text-gray-400">
              Garantia de 30 dias ou seu dinheiro de volta
            </span>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;